
package com.example.androidversions;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AndroidVersionAdapter extends RecyclerView.Adapter<AndroidVersionAdapter.ViewHolder> {

    Context context;
    ArrayList<AndroidVersion> versionList;

    public AndroidVersionAdapter(Context context, ArrayList<AndroidVersion> versionList) {
        this.context = context;
        this.versionList = versionList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_android_version, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        AndroidVersion version = versionList.get(position);

        holder.imgLogo.setImageResource(version.getImageResId());
        holder.txtCodeName.setText(version.getCodeName());
        holder.txtVersion.setText(version.getVersion());

        if (position % 2 == 0) {
            holder.cardView.setCardBackgroundColor(Color.WHITE);
        } else {
            holder.cardView.setCardBackgroundColor(Color.parseColor("#E8F5E9"));
        }

        holder.itemView.setOnClickListener(v -> {
            Toast.makeText(
                    context,
                    "You selected: " + version.getCodeName() + " (" + version.getVersion() + ")",
                    Toast.LENGTH_SHORT
            ).show();
        });
    }

    @Override
    public int getItemCount() {
        return versionList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView imgLogo;
        TextView txtCodeName;
        TextView txtVersion;
        CardView cardView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imgLogo = itemView.findViewById(R.id.imgLogo);
            txtCodeName = itemView.findViewById(R.id.txtCodeName);
            txtVersion = itemView.findViewById(R.id.txtVersion);
            cardView = (CardView) itemView;
        }
    }
}